This is libstdc++.a, libgcc.a, libgcc_eh.a extracted from
ftp://ftp.netlabs.org/pub/gcc/GCC-3.3.5-csd6.zip, converted
to OMF with emxomf and renamed to libstdc++5.lib (GCC major
ABI number), libgcc3.lib, libgcc3_eh.lib, respectively,
to not intermix them with system GCC libs.
